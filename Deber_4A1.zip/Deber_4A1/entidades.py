from abc import ABC, abstractmethod


class Persona(ABC):
    def __init__(self, idCodigo, nombre, estado):
        self.idCodigo = idCodigo
        self.nombre = nombre
        self.estado = estado
    @abstractmethod
    def mostrarDatos(self):
        pass

class Cliente(Persona):
    def __init__(self,idCodigo, nombre, estado, cedula):
        super().__init__(idCodigo, nombre, estado)
        self.cedula = cedula
    def mostrarDatos(self):
        return f"{self.idCodigo}, {self.nombre}, {self.cedula}, {self.estado}"
    def validarCedula(self):
        if len(self.cedula)==10:return f"{self.cedula}"
        else: print("Cedula Invalida")

class Factura:
    def __init__(self, idFactura, cliente, fecha, total, estado):
        self.idFactura = idFactura
        self.cliente = cliente
        self.fecha = fecha
        self.total = total
        self.estado = estado
    def mostrarDatos(self):
        return f"{self.idFactura}, {self.fecha}, {self.total}, {self.cliente.nombre}, {self.estado}"

class Calculo(ABC):
    @abstractmethod
    def realizarPago(self):
        pass

class Pago(Calculo):
    def __init__(self, idPago, fechaPago, valor):
        self.idPago = idPago
        self.fechaPago = fechaPago
        self.valor = valor
    def mostrarDato(self):
        return f"{self.idPago}, {self.fechaPago}, {self.valor}"
    def realizarPago(self, deuda):
        self.valor -= deuda
        return self.valor

class DetCredito:
    def __init__(self, idDetCredito, aamm, cuota, estado):
        self.idDetCredito = idDetCredito
        self.aamm = aamm
        self.cuota = cuota
        self.detPago = []
        self.estado = estado
    def agregarPago(self, idPago, fechaPago, valor):
        pago = Pago(idPago, fechaPago, valor)
        self.detPago.append(pago)
    def mostrarDatos(self):
        return f"{self.idDetCredito}, {self.aamm}, {self.cuota}, {self.estado}"


class CabCredito:
    def __init__(self, idCabCredito, factura, fecha, deuda, numeroCuota, cuota, aammInicial, estado):
        self.idCabCredito = idCabCredito
        self.factura = factura
        self.fecha = fecha
        self.deuda = deuda
        self.numeroCuota = numeroCuota
        self.cuota = cuota
        self.aammInicial = aammInicial
        self.detCredito = []
        self.estado = estado
    def agregarDetalle(self, idDetCredito, aamm, cuota, estado):
        detCredito = DetCredito(idDetCredito, aamm, cuota, estado)
        self.detCredito.append(detCredito)
    def mostrarDato(self):
        return f"{self.idCabCredito}, {self.factura.idFactura}, {self.fecha}, {self.deuda}, {self.numeroCuota}, {self.cuota}, {self.aammInicial}, {self.estado}"
