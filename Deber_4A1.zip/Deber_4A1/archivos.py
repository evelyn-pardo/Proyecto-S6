class Archivo:
    def __init__(self, archivo):
        self.archivo = archivo
    def crear(self, elemento):
        with open("archivos/"+self.archivo + ".txt", "a") as archivo:
            archivo.write(elemento + "\n")
    def buscar(self, elemento):
        with open(f"archivos/{self.archivo}.txt", 'r') as f:
            for linea in f:
                if elemento in linea:
                    return linea.strip()
        return False
    def buscar2(self, elemento):
        with open(f"archivos/{self.archivo}.txt", 'r') as f:
            for linea in f:
                if elemento in linea:
                    return linea.strip().split(",")
        return False
    def leer(self):
        with open(f"archivos/{self.archivo}.txt", "r") as f:
            return f.readlines()
        