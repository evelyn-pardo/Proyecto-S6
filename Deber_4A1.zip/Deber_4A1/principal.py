import os
from archivos import Archivo
from entidades import *
from menu_principal import Menu

def AgregarClientes():
    archivo = Archivo("cliente")
    try:
        with open(f"archivos/{archivo.archivo}.txt", 'r') as f:
            lines = f.readlines()
            idCodigo = len(lines) + 1
    except FileNotFoundError:
        idCodigo = 1
    nombre = input("Ingrese el nombre del cliente: ")
    cedula = input("Ingrese la cedula del cliente: ")
    while len(cedula)==10:
        estado = input("Ingrese el estado del cliente: ")
        cliente = Cliente(idCodigo, nombre, estado, cedula)
        archivo.crear(cliente.mostrarDatos())
        input("Cliente grabado de manera exitosa\nPulse una tecla para poder continuar... ")
        break
    input("Cedula no valida....\nPresione cualquier tecla para continuar: ")

def mostrarCliente():
    cliente_codigo = input("Inserte el id del cliente: ")
    archivo_cliente = Archivo("cliente")
    resultado = archivo_cliente.buscar(cliente_codigo)
    if resultado == False:
        print("No existe el cliente con ese codigo.")
        return
    else:
        idCodigo, nombre, estado, cedula = resultado.split(",")
        cliente = Cliente(idCodigo, nombre, estado, cedula)
        print(cliente.mostrarDatos())
        input("Registro guardado con exito....\nPulse una tecla para continuar... ")



def AgregarFacturas():
    cliente_codigo = input("Inserte el id del cliente: ")
    archivo_cliente = Archivo("cliente")
    resultado = archivo_cliente.buscar(cliente_codigo)
    if resultado == False:
        print(f"No existe el cliente con ese codigo {cliente_codigo}.")
        return
    else:
        idCodigo, nombre, estado, cedula = resultado.split(",")
        cliente = Cliente(idCodigo, nombre, estado, cedula)
        print("Cliente: ",nombre)
        archivo_factura = Archivo("factura")
        try:
            with open(f"archivos/{archivo_factura.archivo}.txt", "r") as f:
                facturas = f.readlines()
                idFactura = len(facturas) + 1
        except FileNotFoundError:
            with open(f"archivos/{archivo_factura.archivo}.txt", "w") as f:
                idFactura = 1
        fecha = input("Ingrese la fecha de la factura: ")
        total = input("Ingrese el total de la factura: ")
        estado = input("Ingrese el estado de la factura: ")
        factura = Factura(str(idFactura), cliente, fecha, total, estado)
        archivo_factura.crear(factura.mostrarDatos())
        input("Registro guardado con exito....\nPulse una tecla para continuar... ")



def mostrarFactura():
    factura_codigo = input("Ingrese el código de la factura que desea consultar: ")
    archivo_factura = Archivo("factura")
    resultado = archivo_factura.buscar2(factura_codigo)
    if resultado == False:
        print("El código de la factura no existe.")
    else:
        idFactura, fecha, total, cliente, estado = resultado[0], resultado[1], resultado[2], resultado[3], resultado[4]
        cliente = Cliente("",cliente,"","")
        factura = Factura(idFactura, cliente, fecha, total, estado)
        print(factura.mostrarDatos())
        input("Pulse una tecla para continuar... ")



def AgregarPagos():
    archivo = Archivo("pago")
    try:
        idPago = len(archivo.leer()) + 1
    except FileNotFoundError:
        with open(f"archivos/{archivo.archivo}.txt", "w") as f:
            pass
        idPago = 1
    fechapago = input("Ingrese la fecha de pago: ")
    valor = input("Ingrese el valor: $")
    pago = Pago(idPago, fechapago, valor)
    archivo.crear(str(pago.mostrarDato()))
    input("Registro guardado con exito....\nPulse una tecla para continuar... ")


def mostrarPago():
    pago_codigo = input("Ingrese el código del pago que desea consultar: ")
    archivo_pago = Archivo("pago")
    resultado = archivo_pago.buscar2(pago_codigo)
    if resultado == False:
        print("El código del pago no existe.")
        return
    else:
        idPago, fechaPago, valor = resultado
        print(f"{idPago}, {fechaPago}, {valor}")
        input("Pulse una tecla para continuar... ")


def AgregarDetalles_Credito():
    codigo_pago = input("Ingrese el código del pago: ")
    archivo_pago = Archivo("pago")
    resultado = archivo_pago.buscar(codigo_pago)
    if resultado == False:
        print("El código del pago no se encuentra en los registros.")
        return
    else:
        idPago, fechapago, valor = resultado.split()
        pago = Pago(idPago, fechapago, valor)
        print("Valor: $",valor)
        archivo_detalle = Archivo("detalle_credito")
        try:
            with open(f"archivos/{archivo_detalle.archivo}.txt", "r") as f:
                detalles = f.readlines()
                idDetCredito = len(detalles) + 1
        except FileNotFoundError:
            with open(f"archivos/{archivo_detalle.archivo}.txt", "w") as f:
                idDetCredito = 1
        aamm = input("Ingrese la fecha de pago: ")
        cuota = input("Ingrese el valor de la cuota: $")
        estado = input("Ingrese el estado del pago: ")
        det = DetCredito(idDetCredito, aamm, cuota, estado)
        archivo_detalle.crear(det.mostrarDatos())
        input("Registro guardado con exito....\nPulse una tecla para continuar... ")



def AgregarCredito():
    codigo_factura = input("Ingrese el codigo de la factura: ")
    archivo_factura = Archivo("factura")
    resultado = archivo_factura.buscar(codigo_factura)
    if resultado == False:
        print("El código de la factura no se encuentra en los registros.")
        return
    else:
        idFactura, fecha, total, cliente, estado = resultado.split(",")
        factura = Factura(idFactura, cliente, fecha, total, estado)
        print(f"Codigo Factura: {idFactura}")
        archivo_credito = Archivo(f"credito")
        try:
            with open(f"archivos/{archivo_credito.archivo}.txt", "r") as f:
                detalles = f.readlines()
                idCredito = len(detalles) + 1
        except FileNotFoundError:
            with open(f"archivos/{archivo_credito.archivo}.txt", "w") as f:
                idCredito = 1   
        print(f"Codigo: {idCredito}")    
        fecha = input("Ingrese la fecha: ")
        deuda = input("Ingrese el valor de la deuda: $")
        numeroCuota = input("Ingrese el N° Cuota: ")
        cuotas = input("Ingrese el valor cuota: $")
        ammm = input("Ingrese la fecha inicial de pago: ")
        credito = CabCredito(idCredito, factura, fecha, deuda, numeroCuota, cuotas, ammm, estado)
        archivo_credito.crear(credito.mostrarDato())
        for j in range(int(numeroCuota)):
            AgregarDetalles_Credito()
        input("Registro guardado con exito....\nPulse una tecla para continuar... ")

def mostrarCredito():
    credito_codigo = input("Ingrese el código de la deuda que desea consultar: ")
    archivo_credito = open("archivos/credito.txt", "r")
    lineas = archivo_credito.readlines()
    encontrado = False
    for linea in lineas:
        campos = linea.strip().split(",")
        if campos[0] == credito_codigo:
            encontrado = True
            idCabCredito, factura, fecha, deuda, numeroCuota, cuota, aammInicial, estado = campos[0], campos[1], campos[2], campos[3], campos[4], campos[5], campos[6], campos[7]
            print(f"Código deuda: {idCabCredito} Codigo Factura: {factura} Fecha: {fecha} Deuda: {deuda} N° Cuota: {numeroCuota} Cuota: {cuota} Fecha Inicial Pago: {aammInicial} Estado: {estado}")
            print("="*60)
            print(f"\nDetalles de crédito:")
            print("="*60)

            archivoDetallecredito = Archivo("detalle_credito")
            lineasDetalleCredito = archivoDetallecredito.leer()
            for lineaDetalleCredito in lineasDetalleCredito:
                idDetCredito, aamm, cuotaDet, estadoDet = lineaDetalleCredito.strip().split(",")
                print(f"Codigo: {idDetCredito} Fecha Inicial Pago: {aamm}  Valor: {cuotaDet}  Estado: {estadoDet}")
                print(f"{idDetCredito}            {aamm}    {cuotaDet}  {estadoDet}")
    if not encontrado:
        print("El código de la deuda no existe.")
    archivo_credito.close()



opc=''
while opc !='6':  
    os.system("cls")
    menu = Menu("Menu Principal",["1) Clientes","2) Facturas","3) Creditos","4) Pago", "5) Consulta General", "6) Salir"])
    opc = menu.menu()
    if opc == "1":
        AgregarClientes()
    elif opc == "2":
        AgregarFacturas()
    elif opc == "3":
        AgregarCredito()
    elif opc == "4":
        AgregarPagos()
    elif opc == "5":
        os.system("cls")
        menu4 = Menu("Consulta General",["1) Clientes","2) Factura", "3) Credito", "4) Pago", "5) Salir"])
        opc4 = menu4.menu()
        if opc4 == "1":
            print("Clientes")
            mostrarCliente()
            input("Presione cualquier tecla para continuar...\n")
        elif opc4 == "2":
            print("Factura")
            mostrarFactura()
            input("Presione cualquier tecla para continuar...\n")

        elif opc4 == "3":
            print("Credito")
            mostrarCredito()
            input("Presione cualquier tecla para continuar...\n")
        elif opc4 == "4":
            print("Pagos")
            mostrarPago()
            input("Presione cualquier tecla para continuar...\n")
        elif opc4 == "5":
            break
        else:
            input("Opcion invalida\nEscriba cualquier tecla para continuar... ")
    elif opc4 == "6":
        break
    else:
          print("Opcion no valida") 

input("Presione una tecla para salir")